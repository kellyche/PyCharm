import workers as wrc
s = wrc.worker
v = wrc.priz
j =wrc.avto
wrc.foo()
o = wrc.Workers()
o.grok()

def calclogic():
    print("Введите должность: ")
    input()
    x = workers.worker