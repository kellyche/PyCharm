a = 37


def foo():
    print("Функция foo(),a=%s"%a)


def bar():
    print("Функция bar(), вызывается функция foo()")
    foo()


class Spam(object):
    def grok(self):
        print("Метод Spam.grok")
