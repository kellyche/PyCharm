gr = 2004
tg = 2023


def std():
    print("Чепрага Думитру Сергеевич")
    calc()

def calc():
    vzr = tg - gr
    print(vzr)


class Student(object):
    def grok(self):
        print("Программист")


