import spam as sp
x = sp.a
sp.foo()
s = sp.Spam()
s.grok()

import familiya as fam
x = fam.gr
y = fam.tg

fam.foo()
a = fam.Familiya()
a.grok()